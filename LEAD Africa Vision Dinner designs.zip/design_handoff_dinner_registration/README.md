# Handoff: leadcma.org/dinner registration (LEAD Africa Vision Dinner, March 6, 2027)

## Overview
This is the public registration page for the LEAD Africa Vision Dinner, plus a private "Register my guests" page for Table Leaders. Every registration writes to Monday.com. It replaces FundEasy: LEAD runs registration through its own page and Monday.com. The page serves three paths:

1. **Guest:** picks the Table Leader who invited them (or "Please seat me").
2. **Table Leader:** registers themselves and gets a private link to their table.
3. **Table Leader registering guests:** uses that private link to add, edit or release guests.

Printed Table Leader materials already describe this flow (see `reference/`), so **labels in this README are user-facing copy. Keep them exact**, or tell LEAD so the print pieces can be updated.

## About the design files
The files in `design/` are **design references built in HTML**. They show the intended look and behavior; they are not production code to copy. Rebuild them in the target environment. LEAD already runs similar forms on **LEAD Learn** (learn.leadcma.org, WordPress + LearnDash), so follow that stack's patterns if this page lives there. Otherwise choose a lightweight framework (e.g. Next.js or a WordPress page with a form handler) that can call the Monday.com GraphQL API **server-side** (never expose the API token in the browser).

The `.dc.html` files need the LEAD design-system runtime to render. Open them from the original project (`vision-dinner/registration/`) to see them live. In this zip they're for reading markup, copy, colors and sizes.

## Fidelity
**High fidelity.** Colors, type, spacing, copy and interactions are final, apart from the placeholders listed at the end.

## Screens / views
Canvas ids match the mockup badges.

### 1a: Register (desktop, 1440 wide)
- **Layout:** two-column grid, `600px | 1fr`.
  - **Left panel** (`#111`, sticky):
    - **Photo block:** 620px tall, `object-fit: cover; object-position: 50% 55%`, grayscale 100%. Gradient: `rgba(17,17,17,.55)` at 0%, clear from 26% to 70%, `#111` at 100%.
    - **Logo:** white-LE&D/red-A `lead-africa-white-red.png`, 64px tall, 56px from top-left.
    - **Details block** below the photo, padding `8px 56px 56px`:
      - Eyebrow "LEAD AFRICA VISION DINNER" in sand `#D0B087`, 14px/700, tracking .16em.
      - H1 "An evening of vision.", Crossten Black 64px, line-height .95, tracking -.02em, white.
      - Red rule 120×4 `#ED1B23`.
      - Detail grid `90px | 1fr`, 16px/1.45, labels in sand 700:
        - When: Saturday, March 6, 2027 / Reception 5:45 pm · Done by 8:15 pm
        - Where: [Venue name and address] / Cleveland–Akron area
        - Cost: None. Dinner is our gift to you.
        - Attire: Business attire strongly suggested. Men: suit or jacket and tie. Women: dress or pants outfit.
      - Paragraph, 15px, opacity .88: "Hear what God is doing through LEAD to equip ministry leaders in East Africa and here at home. Near the end, everyone will be invited to partner with LEAD in prayer and giving."
  - **Right column:** padding `72px 96px 96px`, form max-width 600px.
  - **"What to expect" band** (full width, `#F6F1EA`, padding `72px 96px 80px`):
    - Eyebrow (red): "WHAT TO EXPECT · FROM OUR FIRST VISION DINNER, APRIL 18, 2026"
    - H2 "A warm evening, start to finish.", Crossten Black 40px.
    - 4 photo cards in `repeat(4, 1fr)`, gap 24, photos 240px tall, radius 12, grayscale. Each has a 16px/700 title and a 14px gray line:
      - Reception and welcome / Tables set for the evening / Guests at a table / An invitation to partner
      - Photos are pending from LEAD (April 18, 2026 dinner).

### Form (Registration Form.dc.html), top to bottom
Section gap 36px.
- **Header:**
  - Eyebrow "REGISTER · LEADCMA.ORG/DINNER" (red, 12px/700, .14em).
  - H2 "Reserve your seat." Crossten Black 40px.
  - Sub: "Dinner is our gift to you. It takes about two minutes."
- **"I'm registering as":** two selectable cards (grid auto-fit min 200px, gap 12). Padding 16×18, radius 12, border 2px.
  - Selected: border `#ED1B23`, bg `#FDF2F2`. Unselected: border `#e2e2e2`, bg white.
  - **A guest** / "Someone invited me to their table"
  - **A Table Leader** / "I'm filling a table of ten"
- **Your Table Leader** (guests only):
  - **Search input:** 48px tall, placeholder "Start typing a name", ▾ affordance.
  - **Dropdown:** absolute, white, radius 12, shadow `0 12px 32px rgba(0,0,0,.12)`, max-height 320 scroll.
  - **Each row:** name (15/700), church (12px gray), and a seat pill (11px/700 uppercase, radius 999, white text):
    - **Full** (0 seats): `#ED1B23`, still selectable.
    - **1–3 seats left:** `#1A1A1A`.
    - **4+ seats left:** `#D0B087`.
  - **Last row:** "I don't have a Table Leader. Please seat me." (red 700).
  - **Helper lines:**
    - When a Full table is chosen: "This table is full. You can still choose it, and our coordinator will seat you as close as possible." (`#8a6d45`, 13px)
    - When "seat me" is chosen: "Wonderful. We'll seat you with a Table Leader and let you know before the dinner."
- **Your details:** First name*, Last name*, Email*, Mobile phone* (2-column auto-fit grid, gap 14). Then "Church (optional)".
- **Mailing address:** Street, City (spans 2), State, ZIP.
- **Spouse / guest toggle:**
  - Sand card `#F6F1EA`, radius 12, with title "My spouse or a guest is coming with me" and sub "They'll be seated with you and get their own name tag."
  - Switch: 52×30, on = `#ED1B23`, off = `#cfcfcf`, 24px white knob.
  - When on, an indented block (3px sand left border) adds: Their first name, Their last name, Their email (optional), Their dietary needs (optional).
- **"So we can care for you well":**
  - Dietary needs (optional, one line; placeholder "Vegetarian, gluten-free, allergies…").
  - Accessibility needs (optional, one line; placeholder "Wheelchair access, seating near the front, hearing assistance…").
  - **Guests only, checkbox:** "I'd like to hear about being a Table Leader" / "Fill a table of your own next year, or even this year."
- **Table Leaders only, note card** (4px red top border): "**Next, your guests.** After you register, we'll email you a private link to register your guests and see who's at your table."
- **Submit** (DS primary button, lg, full width): "Reserve my seat" (guest) or "Register as a Table Leader". Below it, in 12px gray: "We'll send a confirmation and a few reminders. We never share your information."
- **Inputs:** 48px tall, padding 0 16, border 1.5px `#cfcfcf`, radius 10, 15px. Focus: border `#ED1B23` plus ring `0 0 0 3px rgba(237,27,35,.18)`. Labels 13px/700. "(optional)" sits inline in 400 `#6b6b6b`.

### 1b / 1g: Thank-you screen (Table Leader / Guest)
- **Left panel:** photo full height. Headline "Thank you for saying yes." (TL) or "We saved you a seat." (guest).
- **Right column:**
  - Red 56px rounded-16 check tile.
  - Eyebrow "YOU'RE REGISTERED".
  - H2: "Thank you for leading a table." (TL) or "See you March 6." (guest).
  - Body:
    - TL: "We've emailed your confirmation and your private guest link. Your Table Leader Coordinator will be in touch soon."
    - Guest: "We've emailed your confirmation. Watch for a reminder a few days before the dinner."
  - Sand summary card with When / Where / Table / Attire. Table shows "[Leader]'s table", "We'll seat you and let you know", or "Your table · 10 seats".
  - **TL only:** card "Now, fill your table." / "Register guests as they say yes. We've also emailed you this private link so you can come back anytime." with the button **Register my guests →**.
  - Buttons: **Add to calendar** (secondary, .ics) and **Register someone else** (ghost, resets the form).

### 1c: Register my guests (private link)
- **Top bar:** white with a bottom border. Logo on the left. On the right: "Vision Dinner · Saturday, March 6, 2027".
- **Body:** grid `1fr | 400px`, gap 48, on `#F4F4F4`.
  - Eyebrow "YOUR TABLE"; H2 "Welcome back, [first name]."; sub "Register each guest the day they say yes. Each one gets their own confirmation and reminders."
  - **Add a guest** card (white, radius 16): First name, Last name, Email, Mobile phone, Dietary needs (optional), Accessibility needs (optional).
    - Note: "No email? Leave it blank and add a phone number. Your coordinator will make sure they get reminders."
    - Button **Add guest to my table**. Requires first name.
  - **Registered at your table** list:
    - Header shows "[n] of 10".
    - Row grid: `1.2fr 1.4fr 1fr 110px 70px` with name (700), email, phone, a status badge (Registered = soft red; Cancelled = neutral) and an **Edit** link (red).
    - **Edit** expands the row inline (bg `#FBF8F3`) with the same six fields, plus:
      - **Save changes:** updates the row and re-sends the guest's confirmation.
      - **Cancel:** closes the row.
      - **Can't come · release their seat:** underlined gray; sets Status = Cancelled and notifies the coordinator.
      - Helper text: "Saving sends the guest an updated confirmation. Releasing a seat lets your coordinator know right away."
  - **Sticky sidebar:**
    - Dark card: "YOUR TABLE", big count (Crossten Black 64) "of 10 seats filled", and a 10-segment meter (filled `#ED1B23`, empty `rgba(255,255,255,.18)`). Message:
      - "[N] seats to go. Someone is waiting to be asked."
      - "One seat to go…" when one seat is left.
      - "Your table is full. Thank you!" when full.
    - Help card: "NEED HELP?", coordinator name, phone and email, "Changes or cancellations? Tell your coordinator right away so seats can be shared."

### 1d: Mobile (390)
- **Photo header:** 420px, gradient to `.9` at the bottom.
- **Overlay text:**
  - Logo, 40px.
  - Eyebrow, 11px.
  - H1, 38px.
  - Red rule, 80×3.
  - Two lines: "Saturday, March 6, 2027 · 5:45 pm" and "[Venue] · Cleveland–Akron area".
- **Form** below, padding `32px 24px 40px`. Grids collapse to one column.
- **"What to expect":** 2×2 grid, photos 130px tall.

### 1e: Confirmation email (640, TL version)
- **Header:** photo 300px tall with "You're registered." (Crossten Black 46, white).
- **Body:**
  - "Hi [first name]," and the thank-you line.
  - Sand detail box: When / Where / Attire.
  - **TL-only block** (red top border): "Register your guests" with the button **Register my guests →** (`#ED1B23`, radius 8). Guests don't get this block.
  - Add to calendar · Get directions.
  - Coordinator line.
  - Signature: Clint Bieri, Co-founder and Executive Director, LEAD.
- **Footer:** LEAD's address, 1-866-LEADCMA, and a "why you received this" line.
- Build it table-based and inline-styled for email clients.

## Interactions and behavior
- **Role switch:**
  - The "Your Table Leader" field and the Table Leader-interest checkbox show for guests only.
  - The "Next, your guests" note and the guest-link block (thank-you screen and email) show for Table Leaders only.
- **Table Leader search:**
  - Matches name and church, case-insensitive.
  - Opens on focus. Picking a row fills the input and closes the list.
  - Typing again clears the selection.
- **Phone fields:**
  - Auto-format to `(330) 555-0100` as you type: US 10 digits, a leading 1 is dropped, deleting characters works normally.
  - Store digits only.
- **Validation:**
  - Required: first name, last name, email (valid format) and mobile phone (10 digits). Guests also need a Table Leader or "seat me".
  - Show inline errors under each field in `#B3141B` 13px, with a red border.
  - Scroll to the first error.
- **Submit:** disable the button and show a spinner while the server call runs. On error, keep the data and show the banner "Something went wrong. Please try again, or call 1-866-LEADCMA."
- **Duplicates:** if the email already exists on the Guests board, update that item rather than creating a new one, and still show success.
- **Private link:**
  - `leadcma.org/dinner/table?t=<token>`. Unguessable token, at least 128 bits, stored on the Table Leaders item.
  - Re-send it on request: "Lost your link?" with email lookup.
- **Seat counts:** Seats left = 10 − registered (non-cancelled) guests connected to the Table Leader. Full tables stay selectable; the coordinator re-seats overflow.
- **Emails:**
  - Confirmation on every registration, and an updated confirmation after an edit.
  - Dinner-week reminders to everyone with an email: Mon 1 pm, Wed 7 pm, day before 11 am, morning of 8 am, 2 hours before doors.
- **No payment or giving fields.** Giving happens on the envelope at the dinner.

## Monday.com data model
- **Location:** workspace **Fundraising** (`17946146`) › folder **Vision Dinner – March 2027** (`21599326`), next to the countdown board `18434832539`. Create two boards and record their IDs and column IDs in `theleadprogram/vision-dinner-countdown` → `dinners/2027-03.json` under `monday.boards`, the same way the countdown board is recorded.

### Vision Dinner Guests – March 2027 (one item per person)
| Column | Type | Source |
|---|---|---|
| Name | item name | first + last |
| Status | status | Registered · Cancelled · Checked in · No-show |
| Role | status | Guest · Table Leader · Spouse/+1 |
| Table Leader | connect boards → Table Leaders | picked leader; empty if "seat me" |
| Seating | status | Assigned · Needs a seat |
| Party ID | text | shared by a registrant and their +1 |
| Email | email | |
| Mobile | phone | digits only |
| Mailing address | long text (or split text columns) | street, city, state, ZIP |
| Church | text | |
| Dietary needs | text | |
| Accessibility needs | text | |
| Table Leader interest | checkbox | guests only |
| Registered by | status | Self · Table Leader link · Staff |

### Table Leaders – March 2027 (one item per Table Leader household)
| Column | Type | Notes |
|---|---|---|
| Name | item name | dropdown display, e.g. "David & Ruth Mwangi" |
| Status | status | Registered · Packet delivered · Active · Stepped back |
| Church | text | shown under the name in search |
| Guests | connect boards (back-link) | |
| Seats filled | mirror/formula | count of connected guests with Status = Registered |
| Seats left | formula | 10 − Seats filled |
| Guest link token | text | |
| Coordinator | people | Table Leader Coordinator / caller |

- **Table Leader registration** creates an item on both boards: Guests (Role = Table Leader) and Table Leaders. Their spouse becomes a Guests item with Role = Spouse/+1 and the same Party ID, connected to that Table Leader.
- **Search data source:** Table Leaders where Status is Registered, Active or Packet delivered, sorted by name. Cache it for about 60 seconds.

## State (front end)
- **Registration form:**
  - `role` ('guest' | 'leader')
  - `tableLeaderId | seatMe`
  - `plusOne` (bool) and the +1 fields
  - field values and errors
  - `submitting` and `submitted`
- **Guests page:**
  - `table` (leader, guests[])
  - `editingId`, plus a `draft` for the open row
  - `addDraft`
  - Derived: filled and left.

## Design tokens
- **Colors:**
  - Red `#ED1B23`; dark red text `#B3141B`.
  - Sand `#D0B087`; sand text `#8a6d45`; sand tint `#F6F1EA`; warm row `#FBF8F3`; red tint `#FDF2F2`.
  - Ink `#1A1A1A`; body gray `#4a4a4a`; muted `#6b6b6b`; placeholder `#9a9a9a`.
  - Input border `#cfcfcf`; hairline `#e2e2e2`; app bg `#F4F4F4`; photo field `#111`.
- **Type:**
  - Crossten (display; Black 900 / Extrabold 800) for headings, tracking -.02em.
  - Open Sans (400/700) for body and UI.
  - Eyebrows: 11–14px, 700, uppercase, tracking .14–.16em.
- **Radii:** inputs 10, cards 12–16, pills 999, check tile 16.
- **Shadows:** dropdown `0 12px 32px rgba(0,0,0,.12)`; focus ring `0 0 0 3px rgba(237,27,35,.18)`.
- **Spacing:** 4px base. Section gap 36, field gap 14, desktop gutters 56/72/96.
- **Brand rules:**
  - Photos are always black and white.
  - Use the red-A black logo on white, and the white logo with the red A on dark or photo backgrounds. Never put a red-A logo on red.
  - No emoji.

## Assets
- `assets/giraffe-2500.jpg`: hero, the B&W acacia/giraffe photo. Apply grayscale in CSS. The original is 11021px wide; serve 2500px or smaller.
- `assets/lead-africa-white-red.png`, `assets/lead-africa-black-red.png`: logos.
- `assets/fonts/`: Crossten Black/Extrabold, Open Sans Regular/Bold. Confirm the Crossten web license.
- **"What to expect" photos:** 4 slots, pending from LEAD.

## Placeholders to fill before launch
- Venue name and address.
- Table Leader Coordinator name, phone and email.
- "What to expect" photos (April 18, 2026).
- Table Leader arrival time (shown in the print checklist).

## Files
- `design/Registration Page.dc.html`: canvas with 1a–1g, data map and behavior notes.
- `design/Registration Form.dc.html`: the form and thank-you component (props `initialRole`, `initialSubmitted`, `initialPlusOne`).
- `reference/How to Invite and Register.dc.html`, `reference/Invitation Checklist.dc.html`: printed Table Leader materials that quote this page's labels.
- Source repo for the Monday setup: `theleadprogram/vision-dinner-countdown` (README, `dinners/2027-03.json`).
