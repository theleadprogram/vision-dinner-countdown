# Brief for Claude (chat): LEAD Africa Vision Dinner 2027

Paste or upload this into a Claude Project so any chat can pick up where design left off. Use it with the Vision Dinner Knowledge Pack (brief, images and source files of every piece).

## The event
- **Name:** LEAD Africa Vision Dinner. Saturday, March 6, 2027, Cleveland–Akron area. The venue is not yet announced.
- **Program and timing:** Follows the Fundraising Masterminds Perfect Vision Dinner model with LEAD's settled standards. Reception 5:45 pm, doors 6:20 pm, done about 8:15 pm. No cost to guests.
- **Previous dinner:** The first LEAD Vision Dinner was April 18, 2026. (The web banners still say "1st Annual"; Clint chose to leave them as is.)
- **Who invites:** "Table Leaders" (LEAD's term; never "Table Hosts") fill tables of ten. Each is supported by a Table Leader Coordinator.
- **Registration:** leadcma.org/dinner, writing to Monday.com. Not FundEasy.

## What's designed (all verified on the Vision Dinner Kit list)
- **Guest pieces:**
  - Dinner Invitation (MOO 5.66×8.66)
  - Email Invitation
  - Web Banners
  - Slide Deck (16:9)
  - Evening Program
  - Light box triptych, banners 1–5 and welcome banner
  - Registration page banners
  - Giving Envelope (#10, front only, ACH)
  - Contact Card (MOO 4×6)
  - Involvement Card (MOO 5×7)
- **Table Leader Resources** (packet: 9×12 envelope, hand-delivered within 24–48 hours of a yes):
  - Intro Letter from Clint
  - Invitation Checklist
  - How to Invite and Register Guests (front: steps; back: "What the evening looks like" photos)
  - Save-the-date (4×6 postcard, 10 per packet, plus the 12-week mailing)
  - Invitations (10)
  - Don't Forget card (4×6 postcard, 10, two weeks out)
- **Registration page mockup:** leadcma.org/dinner, with a Claude Code handoff in `README.md`.

## Settled decisions
- **Brand:**
  - Photos in black and white only; the giraffe/acacia photo is the Vision Dinner hero image.
  - Red-A logo on white; white logo with red A on dark or photo backgrounds; never a red-A logo on red.
  - Fonts: Crossten and Open Sans. No emoji.
- **Language:** "opportunity," "partners," "gifts." Never "need," "donors" or "donations." Tone of abundance: expect full tables; "Someone is waiting to be asked."
- **Registration rules:**
  - One record per person.
  - Spouse or guest registers on the same form.
  - Table Leaders get a private link to add, edit and release guests.
  - Seat pills: Full = red, 1–3 = black, 4+ = sand, all with white text.
  - Full tables are still selectable.
  - "Please seat me" for guests without a Table Leader.
- **Postcards:** leave the bottom 0.75" of the address side blank for the USPS barcode.

## Open items
- Venue name and address. It appears on: Letter, Checklist, Don't Forget card, registration page, emails.
- Table Leader Coordinator name, phone and email. It appears on: Letter, Checklist footer, How-to sheet, guests page.
- Table Leader arrival time (Checklist).
- Photos from the April 18, 2026 dinner for 4 "What to expect" slots: reception, tables set, guests at a table, giving moment.
- Email invitation uses a portrait instead of the giraffe.
- Once Claude Code finishes leadcma.org/dinner, re-check How to Invite wording against the live button labels.
- Confirm "Doors 6:20 pm" on the Don't Forget card.

## How to help next
- **Copy:** write in LEAD's voice, warm and direct, a mentor, not a marketer. Use the lead-voice and perfect-vision-dinner skills.
- **Before changing anything printed:** remember packet pieces quote registration labels word for word ("A Table Leader," "Add a guest," "Can't come · release their seat"). Change both together.
- **Where things live:** dinner-specific Monday.com IDs are in `theleadprogram/vision-dinner-countdown` → `dinners/2027-03.json`.
